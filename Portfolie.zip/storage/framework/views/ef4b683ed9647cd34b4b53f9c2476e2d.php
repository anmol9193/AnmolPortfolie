<!-- TECH MARQUEE -->
<div class="marquee"><div class="m-track" id="techTrack"></div></div>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/site/sections/marquee.blade.php ENDPATH**/ ?>