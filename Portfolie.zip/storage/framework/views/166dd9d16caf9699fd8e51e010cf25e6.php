<?php $__env->startSection('title', 'Edit '.$current['label'].' page'); ?>

<?php
    $checked = old('sections', $current['sections']);
    $isHome = $current['key'] === 'home';
?>

<?php $__env->startSection('content'); ?>
  <div class="head">
    <div class="eyebrow">Site pages</div>
    <h1>Edit <span class="serif accent"><?php echo e($current['label']); ?></span> page</h1>
  </div>

  <form class="card" method="POST" action="<?php echo e(route('admin.pages.update', $current['key'])); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="form-grid">
      <div class="fld">
        <label for="f-label">Menu name <span class="req">*</span></label>
        <input id="f-label" type="text" name="label" value="<?php echo e(old('label', $current['label'])); ?>" required maxlength="40">
        <span class="hint">Shown in the header menu and footer links.</span>
        <?php $__errorArgs = ['label'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="fld">
        <label for="f-title">Browser title</label>
        <input id="f-title" type="text" name="title" value="<?php echo e(old('title', $current['title'])); ?>" maxlength="80">
        <span class="hint"><?php echo e($isHome ? 'Leave empty to use your name and tagline.' : 'The tab title, followed by your name.'); ?></span>
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="fld wide">
        <label class="check">
          <input type="hidden" name="nav" value="0">
          <input type="checkbox" name="nav" value="1" <?php if(old('nav', $current['nav'])): echo 'checked'; endif; ?>> Show this page in the header menu
        </label>
        <span class="hint">Address: <?php echo e(url($current['path'])); ?></span>
      </div>

      <div class="fld wide">
        <span class="lbl">Sections on this page <span class="req">*</span></span>
        <div class="checks">
          <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label class="check"><input type="checkbox" name="sections[]" value="<?php echo e($key); ?>" <?php if(in_array($key, $checked)): echo 'checked'; endif; ?>> <?php echo e($label); ?></label>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <span class="hint"><?php echo e($isHome ? 'On the home page the order of the middle sections comes from the active theme.' : 'Sections always appear in the order listed here.'); ?></span>
        <?php $__errorArgs = ['sections'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="err"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
    </div>

    <div class="form-foot">
      <button class="btn btn-primary" type="submit">Save changes
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
      </button>
      <a class="btn" href="<?php echo e(route('admin.pages')); ?>">Cancel</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Mylaravel\Portfolie\resources\views/admin/page-form.blade.php ENDPATH**/ ?>