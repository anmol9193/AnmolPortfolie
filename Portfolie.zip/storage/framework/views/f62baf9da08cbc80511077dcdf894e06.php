<!-- PROCESS -->
<section id="process" style="padding-top:40px">
  <div class="container">
    <?php echo $__env->make('site.sections._head', ['group' => 'process'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="process">
      <?php $__currentLoopData = items('process'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="step reveal">
          <div class="dot"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><?php echo e(icon($step->field('icon'), 'code')); ?></svg></div>
          <div class="k"><?php echo e(content('labels.step')); ?> <?php echo e(str_pad($i + 1, 2, '0', STR_PAD_LEFT)); ?></div><h3><?php echo e($step->field('title')); ?></h3><p><?php echo e($step->field('description')); ?></p>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/site/sections/process.blade.php ENDPATH**/ ?>