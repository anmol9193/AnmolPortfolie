<?php
    $wa = content('contact.whatsapp');
    $cv = content('site.cv');
?>
<!-- HERO -->
<section class="hero" id="home">
  <div class="container">
    <div class="hero-grid">
      <div>
        <?php if(content('hero.status')): ?>
          <div class="status"><span class="pulse"></span><?php echo e(content('hero.status')); ?></div>
        <?php endif; ?>
        <h1>
          <span class="line"><span><?php echo e(content('hero.first_name')); ?></span></span>
          <span class="line"><span><?php echo e(content('hero.last_name')); ?><span class="serif">.</span></span></span>
        </h1>
        <p class="hero-sub"><?php echo e(rich(content('hero.sub'))); ?></p>
        <div class="role"><span class="prompt">~/<?php echo e(Str::slug(content('hero.first_name')) ?: 'me'); ?> $</span> <span id="typed"></span><span class="cursor"></span></div>
        <div class="btns">
          <a href="<?php echo e($onHome ? '#projects' : url('projects')); ?>" class="btn btn-primary magnetic"><?php echo e(content('hero.primary_button')); ?>

            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
          <?php if($cv): ?>
            <a href="<?php echo e(media($cv)); ?>" download class="btn btn-ghost magnetic"><?php echo e(content('hero.cv_button')); ?>

              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12l7 7 7-7"/></svg></a>
          <?php endif; ?>
        </div>
        <div class="hero-social"><span><?php echo e(content('labels.hero_social')); ?></span>
          <?php if(content('contact.linkedin')): ?>
            <a href="<?php echo e(content('contact.linkedin')); ?>" target="_blank" rel="noopener" aria-label="LinkedIn"><svg viewBox="0 0 24 24" fill="currentColor"><?php echo $__env->make('site.icons.linkedin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></svg></a>
          <?php endif; ?>
          <?php if(content('contact.instagram')): ?>
            <a href="<?php echo e(content('contact.instagram')); ?>" target="_blank" rel="noopener" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><?php echo $__env->make('site.icons.instagram', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></svg></a>
          <?php endif; ?>
          <?php if($wa): ?>
            <a href="https://wa.me/<?php echo e($wa); ?>" target="_blank" rel="noopener" aria-label="WhatsApp"><svg viewBox="0 0 24 24" fill="currentColor"><?php echo $__env->make('site.icons.whatsapp', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></svg></a>
          <?php endif; ?>
        </div>
      </div>
      <div class="hero-visual reveal">
        <div class="spin-badge">
          <svg viewBox="0 0 120 120"><defs><path id="circ" d="M60,60 m-47,0 a47,47 0 1,1 94,0 a47,47 0 1,1 -94,0"/></defs><text><textPath href="#circ"><?php echo e(content('hero.badge')); ?></textPath></text></svg>
          <svg class="star" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0l2.6 9.4L24 12l-9.4 2.6L12 24l-2.6-9.4L0 12l9.4-2.6z"/></svg>
        </div>
        <div class="photo-card">
          <img src="<?php echo e(media(content('site.photo'))); ?>" alt="Portrait of <?php echo e(content('site.name')); ?>">
          <div class="ph-tag"><div><b><?php echo e(content('hero.photo_name')); ?></b><span><?php echo e(content('hero.photo_role')); ?></span></div><span class="dotc"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17L17 7M7 7h10v10"/></svg></span></div>
        </div>
      </div>
    </div>
    <div class="hero-foot">
      <div class="hero-stats">
        <?php $__currentLoopData = \App\Support\Content::stats('hero.stats'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$number, $suffix, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="stat"><b><span class="count" data-to="<?php echo e($number); ?>">0</span><?php if($suffix): ?><sup><?php echo e($suffix); ?></sup><?php endif; ?></b><span><?php echo e($label); ?></span></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php if(content('labels.scroll_hint')): ?>
        <a href="#about" class="scroll-hint"><i></i><?php echo e(content('labels.scroll_hint')); ?></a>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/site/sections/hero.blade.php ENDPATH**/ ?>