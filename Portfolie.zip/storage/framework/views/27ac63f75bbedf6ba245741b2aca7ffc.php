<?php $__env->startSection('title', ($item->exists ? 'Edit ' : 'Add ').$collection['singular']); ?>

<?php $__env->startSection('content'); ?>
  <div class="head">
    <div class="eyebrow"><?php echo e($collection['label']); ?></div>
    <h1><?php echo e($item->exists ? 'Edit' : 'Add'); ?> <span class="serif accent"><?php echo e($collection['singular']); ?></span></h1>
  </div>

  <form class="card" method="POST" enctype="multipart/form-data"
        action="<?php echo e($item->exists ? route('admin.items.update', [$type, $item]) : route('admin.items.store', $type)); ?>">
    <?php echo csrf_field(); ?>
    <?php if($item->exists): ?>
      <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <?php if($errors->any()): ?>
      <div class="note bad" role="alert">Please fix the highlighted fields.</div>
    <?php endif; ?>

    <div class="form-grid">
      <?php $__currentLoopData = $collection['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            [$label, $kind] = $field;
            $required = $field['required'] ?? false;
            $saved = $item->exists ? $item->field($key, '') : ($field['default'] ?? '');
            $value = old($key, $saved);
        ?>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['fld', 'wide' => in_array($kind, ['textarea', 'image', 'icon'])]); ?>">
          <?php if($kind === 'checkbox'): ?>
            <span class="lbl">&nbsp;</span>
            <label class="check">
              <input type="hidden" name="<?php echo e($key); ?>" value="0">
              <input type="checkbox" name="<?php echo e($key); ?>" value="1" <?php if($value): echo 'checked'; endif; ?>> <?php echo e($label); ?>

            </label>
          <?php else: ?>
            <label for="f-<?php echo e($key); ?>"><?php echo e($label); ?> <?php if($required): ?><span class="req">*</span><?php endif; ?></label>

            <?php if($kind === 'textarea'): ?>
              <textarea id="f-<?php echo e($key); ?>" name="<?php echo e($key); ?>" rows="4" <?php if($required): echo 'required'; endif; ?>><?php echo e($value); ?></textarea>
            <?php elseif($kind === 'select'): ?>
              <select id="f-<?php echo e($key); ?>" name="<?php echo e($key); ?>">
                <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($optionKey); ?>" <?php if($value === $optionKey): echo 'selected'; endif; ?>><?php echo e($optionLabel); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            <?php elseif($kind === 'color'): ?>
              <input id="f-<?php echo e($key); ?>" type="color" name="<?php echo e($key); ?>" value="<?php echo e($value ?: '#ff5b2e'); ?>">
            <?php elseif($kind === 'icon'): ?>
              <div class="icons">
                <?php $__currentLoopData = config('icons'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $svg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <label title="<?php echo e($name); ?>">
                    <input type="radio" name="<?php echo e($key); ?>" value="<?php echo e($name); ?>" <?php if($value === $name): echo 'checked'; endif; ?>>
                    <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><?php echo $svg; ?></svg></span>
                  </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            <?php elseif($kind === 'image'): ?>
              <?php if($saved): ?>
                <div class="thumb">
                  <img src="<?php echo e(media($saved)); ?>" alt="">
                  <label class="check"><input type="checkbox" name="remove_<?php echo e($key); ?>" value="1"> Remove this image</label>
                </div>
              <?php endif; ?>
              <input id="f-<?php echo e($key); ?>" type="file" name="<?php echo e($key); ?>" accept="image/jpeg,image/png,image/webp">
              <span class="hint">JPG, PNG or WebP, up to 4 MB. Leave empty to keep the current one.</span>
            <?php else: ?>
              <input id="f-<?php echo e($key); ?>" type="<?php echo e($kind === 'url' ? 'url' : 'text'); ?>" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>" <?php if($required): echo 'required'; endif; ?>>
            <?php endif; ?>
          <?php endif; ?>

          <?php if(isset($field['hint'])): ?>
            <span class="hint"><?php echo e($field['hint']); ?></span>
          <?php endif; ?>
          <?php $__errorArgs = [$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="err"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <div class="fld">
        <label for="f-position">Order</label>
        <input id="f-position" type="number" name="position" min="0" max="9999" value="<?php echo e(old('position', $item->position)); ?>">
        <span class="hint">Lower numbers show first.</span>
        <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="err"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
    </div>

    <div class="form-foot">
      <button class="btn btn-primary" type="submit"><?php echo e($item->exists ? 'Save changes' : 'Add '.$collection['singular']); ?>

        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
      </button>
      <a class="btn" href="<?php echo e(route('admin.items.index', $type)); ?>">Cancel</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Mylaravel\Portfolie\resources\views/admin/items/form.blade.php ENDPATH**/ ?>