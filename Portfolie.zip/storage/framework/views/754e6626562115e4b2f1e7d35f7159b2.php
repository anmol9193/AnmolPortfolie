<?php ($pages = \App\Support\Pages::all()); ?>
<footer>
  <div class="container">
    <div class="f-big"><?php echo e(content('site.name')); ?></div>
    <div class="f-bottom">
      <span><?php echo e(str_replace('{year}', date('Y'), content('site.footer'))); ?></span>
      <div class="f-links">
        <?php $__currentLoopData = ['about', 'projects', 'contact']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e(url($pages[$key]['path'])); ?>"><?php echo e($pages[$key]['label']); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(content('site.cv') && content('labels.footer_resume')): ?>
          <a href="<?php echo e(media(content('site.cv'))); ?>" download><?php echo e(content('labels.footer_resume')); ?></a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</footer>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/site/footer.blade.php ENDPATH**/ ?>