<?php
    $go = '<svg class="go" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>';
    $phone = content('contact.phone');
?>
<!-- CONTACT -->
<section id="contact">
  <div class="container">
    <?php echo $__env->make('site.sections._head', ['group' => 'contact'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="contact-grid">
      <div class="c-list">
        <?php if(content('contact.email')): ?>
          <a href="mailto:<?php echo e(content('contact.email')); ?>" class="card c-item reveal">
            <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><path d="M22 6l-10 7L2 6"/></svg></div>
            <div><small><?php echo e(content('labels.email_title')); ?></small><b><?php echo e(content('contact.email')); ?></b></div>
            <?php echo $go; ?>

          </a>
        <?php endif; ?>
        <?php if($phone): ?>
          <a href="tel:<?php echo e(preg_replace('/[^\d+]/', '', $phone)); ?>" class="card c-item reveal">
            <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg></div>
            <div><small><?php echo e(content('labels.phone_title')); ?></small><b><?php echo e($phone); ?></b></div>
            <?php echo $go; ?>

          </a>
        <?php endif; ?>
        <?php if(content('contact.whatsapp')): ?>
          <a href="https://wa.me/<?php echo e(content('contact.whatsapp')); ?>" target="_blank" rel="noopener" class="card c-item reveal">
            <div class="ic"><svg viewBox="0 0 24 24" fill="currentColor"><?php echo $__env->make('site.icons.whatsapp', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></svg></div>
            <div><small><?php echo e(content('labels.whatsapp_title')); ?></small><b><?php echo e(content('labels.whatsapp_text')); ?></b></div>
            <?php echo $go; ?>

          </a>
        <?php endif; ?>
        <?php if(content('contact.linkedin')): ?>
          <a href="<?php echo e(content('contact.linkedin')); ?>" target="_blank" rel="noopener" class="card c-item reveal">
            <div class="ic"><svg viewBox="0 0 24 24" fill="currentColor"><?php echo $__env->make('site.icons.linkedin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></svg></div>
            <div><small><?php echo e(content('labels.linkedin_title')); ?></small><b><?php echo e(content('contact.linkedin_label')); ?></b></div>
            <?php echo $go; ?>

          </a>
        <?php endif; ?>
        <?php if(content('contact.instagram')): ?>
          <a href="<?php echo e(content('contact.instagram')); ?>" target="_blank" rel="noopener" class="card c-item reveal">
            <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><?php echo $__env->make('site.icons.instagram', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></svg></div>
            <div><small><?php echo e(content('labels.instagram_title')); ?></small><b><?php echo e(content('contact.instagram_label')); ?></b></div>
            <?php echo $go; ?>

          </a>
        <?php endif; ?>
        <?php if(content('contact.address')): ?>
          <div class="card c-item reveal">
            <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div>
            <div><small><?php echo e(content('labels.address_title')); ?></small><b><?php echo e(content('contact.address')); ?></b></div>
          </div>
        <?php endif; ?>
      </div>
      <form class="card reveal" id="contactForm" method="POST" action="<?php echo e(route('contact.send')); ?>">
        <?php echo csrf_field(); ?>
        <h3><?php echo e(content('contact.form_title')); ?></h3>
        <p><?php echo e(content('contact.form_text')); ?></p>

        <?php if(session('contact_sent')): ?>
          <div class="form-note ok" role="status">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
            <span><?php echo e(content('contact.form_success')); ?></span>
          </div>
        <?php endif; ?>
        <?php if($errors->contact->any()): ?>
          <div class="form-note bad" role="alert">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
            <span><?php echo e($errors->contact->first()); ?></span>
          </div>
        <?php endif; ?>


        <div class="f-row">
          <div class="field"><input id="fName" name="name" value="<?php echo e(old('name')); ?>" required maxlength="80" autocomplete="name" placeholder=" "><label for="fName"><?php echo e(content('labels.form_name')); ?></label></div>
          <div class="field"><input id="fEmail" name="email" type="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder=" "><label for="fEmail"><?php echo e(content('labels.form_email')); ?></label></div>
        </div>
        <div class="f-row">
          <div class="field"><input id="fPhone" name="phone" type="tel" value="<?php echo e(old('phone')); ?>" required maxlength="30" autocomplete="tel" placeholder=" "><label for="fPhone"><?php echo e(content('labels.form_phone')); ?></label></div>
          <div class="field"><input id="fSubject" name="subject" value="<?php echo e(old('subject')); ?>" required maxlength="150" placeholder=" "><label for="fSubject"><?php echo e(content('labels.form_subject')); ?></label></div>
        </div>
        <div class="field"><textarea id="fMsg" name="message" rows="5" required maxlength="3000" placeholder=" "><?php echo e(old('message')); ?></textarea><label for="fMsg"><?php echo e(content('labels.form_message')); ?></label></div>
        <button class="btn btn-primary" id="contactBtn" type="submit"><span><?php echo e(content('labels.form_button')); ?></span>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg></button>
      </form>
    </div>
  </div>
</section>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/site/sections/contact.blade.php ENDPATH**/ ?>