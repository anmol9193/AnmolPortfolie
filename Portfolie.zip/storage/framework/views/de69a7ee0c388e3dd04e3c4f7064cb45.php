<?php
    $groups = items('skills')->groupBy(fn ($skill) => $skill->field('group') ?: 'Skills');
?>
<!-- SKILLS -->
<section id="skills">
  <div class="container">
    <?php echo $__env->make('site.sections._head', ['group' => 'skills'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="skill-groups">
      <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $skills): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="card sg reveal" <?php if($loop->last && $loop->odd): ?> style="grid-column:1/-1" <?php endif; ?>>
          <div class="sg-head"><h3><?php echo e($group); ?></h3><span><?php echo e($skills->count()); ?> <?php echo e(content('labels.tools')); ?></span></div>
          <div class="sk-list">
            <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="sk">
                <?php if($skill->field('logo')): ?>
                  <img class="sk-logo" src="<?php echo e(media($skill->field('logo'))); ?>" alt="">
                <?php elseif($skill->field('devicon')): ?>
                  <i class="devicon-<?php echo e($skill->field('devicon')); ?> colored"></i>
                <?php else: ?>
                  <svg class="svg-i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><?php echo e(icon('devices')); ?></svg>
                <?php endif; ?>
                <?php echo e($skill->field('name')); ?>

              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/site/sections/skills.blade.php ENDPATH**/ ?>