
<div class="sec-head">
  <div class="reveal">
    <div class="eyebrow"><?php echo e(content("$group.eyebrow")); ?></div>
    <h2><?php echo e(rich(content("$group.title"))); ?></h2>
  </div>
  <?php if(content("$group.sub")): ?>
    <p class="reveal"><?php echo e(content("$group.sub")); ?></p>
  <?php endif; ?>
</div>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/site/sections/_head.blade.php ENDPATH**/ ?>