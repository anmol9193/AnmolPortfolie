<!-- SERVICES -->
<section id="services" style="padding-top:40px">
  <div class="container">
    <?php echo $__env->make('site.sections._head', ['group' => 'services'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="services">
      <?php $__currentLoopData = items('services'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card svc reveal">
          <span class="n"><?php echo e(str_pad($i + 1, 2, '0', STR_PAD_LEFT)); ?></span>
          <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><?php echo e(icon($service->field('icon'), 'code')); ?></svg></div>
          <h3><?php echo e($service->field('title')); ?></h3>
          <p><?php echo e($service->field('description')); ?></p>
          <?php if($service->field('stack')): ?>
            <div class="stack"><?php echo e($service->field('stack')); ?></div>
          <?php endif; ?>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/site/sections/services.blade.php ENDPATH**/ ?>