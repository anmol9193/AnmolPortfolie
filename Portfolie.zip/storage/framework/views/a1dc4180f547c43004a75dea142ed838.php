<?php $__env->startSection('title', 'Site pages'); ?>

<?php $__env->startSection('content'); ?>
  <div class="head">
    <div class="eyebrow">Site pages</div>
    <h1>Your public <span class="serif accent">pages</span></h1>
  </div>

  <div class="card">
    <div class="card-head"><h2>All pages</h2><span><?php echo e($pages->count()); ?> pages</span></div>
    <ul class="list">
      <?php $__currentLoopData = $pages->values(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          <span class="pos"><?php echo e(str_pad($i + 1, 2, '0', STR_PAD_LEFT)); ?></span>
          <span class="info">
            <b><?php echo e($page['label']); ?> <?php if($page['nav']): ?><span class="badge" style="margin-left:8px">In menu</span><?php endif; ?></b>
            <small><?php echo e($page['path']); ?> · <?php echo e(collect($page['sections'])->map(fn ($s) => Str::before(config("site.sections.$s"), ' ('))->implode(', ')); ?></small>
          </span>
          <span class="acts">
            <a class="sm" href="<?php echo e(url($page['path'])); ?>" target="_blank" rel="noopener">View</a>
            <a class="sm" href="<?php echo e(route('admin.pages.edit', $page['key'])); ?>">Edit</a>
          </span>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Mylaravel\Portfolie\resources\views/admin/pages.blade.php ENDPATH**/ ?>