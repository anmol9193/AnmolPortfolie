<?php $__env->startSection('title', 'Page content'); ?>

<?php $__env->startSection('content'); ?>
  <div class="head">
    <div class="eyebrow">Page content</div>
    <h1>Texts, photo &amp; <span class="serif accent">CV</span></h1>
  </div>

  <div class="tabs">
    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo e(route('admin.content', $key)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $key === $group]); ?>"><?php echo e($g['label']); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <form class="card" method="POST" action="<?php echo e(route('admin.content.update', $group)); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <?php if($errors->any()): ?>
      <div class="note bad" role="alert">Please fix the highlighted fields.</div>
    <?php endif; ?>

    <div class="form-grid">
      <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            [$label, $type] = $field;
            $hint = $field[3] ?? null;
            $value = old($key, content("$group.$key"));
        ?>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['fld', 'wide' => in_array($type, ['textarea', 'lines', 'image', 'file', 'favicon'])]); ?>">
          <label for="f-<?php echo e($key); ?>"><?php echo e($label); ?></label>

          <?php if($type === 'textarea' || $type === 'lines'): ?>
            <textarea id="f-<?php echo e($key); ?>" name="<?php echo e($key); ?>" rows="<?php echo e($type === 'lines' ? 5 : 3); ?>"><?php echo e($value); ?></textarea>
          <?php elseif($type === 'favicon'): ?>
            <?php if(content("$group.$key")): ?>
              <div class="thumb">
                <img src="<?php echo e(media(content("$group.$key"))); ?>" alt="" style="width:48px;height:48px;object-fit:contain;padding:6px">
                <label class="check"><input type="checkbox" name="remove_<?php echo e($key); ?>" value="1"> Remove and use my logo letters</label>
              </div>
            <?php endif; ?>
            <input id="f-<?php echo e($key); ?>" type="file" name="<?php echo e($key); ?>" accept=".png,.ico,.jpg,.jpeg,.webp,image/png,image/x-icon,image/jpeg,image/webp">
            <span class="hint">PNG, ICO, JPG or WebP, up to 1 MB. Leave empty to keep the current one.</span>
          <?php elseif($type === 'image'): ?>
            <?php if(content("$group.$key")): ?>
              <div class="thumb"><img src="<?php echo e(media(content("$group.$key"))); ?>" alt=""><a href="<?php echo e(media(content("$group.$key"))); ?>" target="_blank" rel="noopener">View current</a></div>
            <?php endif; ?>
            <input id="f-<?php echo e($key); ?>" type="file" name="<?php echo e($key); ?>" accept="image/jpeg,image/png,image/webp">
            <span class="hint">JPG, PNG or WebP, up to 4 MB. Leave empty to keep the current one.</span>
          <?php elseif($type === 'file'): ?>
            <?php if(content("$group.$key")): ?>
              <div class="thumb"><a href="<?php echo e(media(content("$group.$key"))); ?>" target="_blank" rel="noopener">View current file</a></div>
            <?php endif; ?>
            <input id="f-<?php echo e($key); ?>" type="file" name="<?php echo e($key); ?>" accept="application/pdf">
            <span class="hint">PDF, up to 8 MB. Leave empty to keep the current one.</span>
          <?php else: ?>
            <input id="f-<?php echo e($key); ?>" type="text" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
          <?php endif; ?>

          <?php if($hint): ?>
            <span class="hint"><?php echo e($hint); ?></span>
          <?php endif; ?>
          <?php $__errorArgs = [$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="err"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="form-foot">
      <button class="btn btn-primary" type="submit">Save changes
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
      </button>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Mylaravel\Portfolie\resources\views/admin/content.blade.php ENDPATH**/ ?>