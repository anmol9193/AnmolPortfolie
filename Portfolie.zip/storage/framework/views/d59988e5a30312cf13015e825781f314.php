<!-- EXPERIENCE -->
<section id="experience" style="padding-top:40px">
  <div class="container">
    <?php echo $__env->make('site.sections._head', ['group' => 'experience'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="exp-list">
      <?php $__currentLoopData = items('experiences'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="exp reveal">
          <div class="exp-date"><?php echo e($job->field('date')); ?><?php if($job->field('current')): ?><br><span class="now"><?php echo e(content('labels.current_role')); ?></span><?php endif; ?></div>
          <div>
            <h3><?php echo e($job->field('title')); ?></h3>
            <h4><?php echo e($job->field('company')); ?></h4>
            <p><?php echo e($job->field('description')); ?></p>
            <?php if($job->list('tags')): ?>
              <div class="tags"><?php $__currentLoopData = $job->list('tags'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span class="tag"><?php echo e($tag); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
            <?php endif; ?>
          </div>
          <div class="exp-loc"><?php echo e($job->field('location')); ?></div>
          <div class="exp-big"><?php echo e($job->field('year')); ?></div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/site/sections/experience.blade.php ENDPATH**/ ?>