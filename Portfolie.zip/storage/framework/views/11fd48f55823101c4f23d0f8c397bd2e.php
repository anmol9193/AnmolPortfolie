<?php
    $pages = \App\Support\Pages::all();
    $contact = $pages->get('contact');
?>
<!-- NAV -->
<nav>
  <div class="nav-inner">
    <a href="<?php echo e($onHome ? '#home' : url('/')); ?>" class="logo"><b><?php echo e(content('site.logo_mark')); ?></b><?php echo e(content('site.logo_text')); ?></a>
    <ul class="nav-links" id="navLinks">
      <?php $__currentLoopData = $pages->where('nav', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(url($link['path'])); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => $page === $link['key']]); ?>"><?php echo e($link['label']); ?></a></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <div class="nav-actions">
      
      <a href="<?php echo e(url($contact['path'])); ?>" class="hire"><?php echo e($contact['label']); ?></a>
      <button class="icon-btn menu-btn" id="menuBtn" aria-label="Open menu">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 8h16M4 16h16"/></svg>
      </button>
    </div>
  </div>
</nav>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/site/nav.blade.php ENDPATH**/ ?>