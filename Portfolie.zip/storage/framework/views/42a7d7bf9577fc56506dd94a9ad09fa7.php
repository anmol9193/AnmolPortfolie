<?php $__env->startSection('title', $collection['label']); ?>

<?php
    $imageField = collect($collection['fields'])->search(fn ($field) => $field[1] === 'image');
?>

<?php $__env->startSection('content'); ?>
  <div class="head head-row">
    <div>
      <div class="eyebrow"><?php echo e($collection['label']); ?></div>
      <h1>Your <span class="serif accent"><?php echo e(Str::lower($collection['label'])); ?></span></h1>
    </div>
    <a href="<?php echo e(route('admin.items.create', $type)); ?>" class="btn btn-primary">Add <?php echo e($collection['singular']); ?>

      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg></a>
  </div>


  <div class="card">
    <div class="card-head"><h2>All <?php echo e(Str::lower($collection['label'])); ?></h2><span><?php echo e($items->count()); ?> <?php echo e(Str::plural('item', $items->count())); ?></span></div>

    <?php if($items->isEmpty()): ?>
      <p class="empty">Nothing here yet. Add your first <?php echo e($collection['singular']); ?>.</p>
    <?php else: ?>
      <ul class="list">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li>
            <span class="pos"><?php echo e(str_pad($item->position, 2, '0', STR_PAD_LEFT)); ?></span>
            <?php if($imageField): ?>
              <?php if($item->field($imageField)): ?>
                <img src="<?php echo e(media($item->field($imageField))); ?>" alt="">
              <?php else: ?>
                <span class="ph" style="background:linear-gradient(145deg,<?php echo e($item->field('color_1', 'var(--surface-2)')); ?>,<?php echo e($item->field('color_2', 'var(--border)')); ?>)"></span>
              <?php endif; ?>
            <?php endif; ?>
            <span class="info">
              <b><?php echo e($item->field($collection['title']) ?: 'Untitled'); ?></b>
              <small><?php echo e($item->field($collection['subtitle'])); ?></small>
            </span>
            <span class="acts">
              <a class="sm" href="<?php echo e(route('admin.items.edit', [$type, $item])); ?>">Edit</a>
              <form method="POST" action="<?php echo e(route('admin.items.destroy', [$type, $item])); ?>" data-confirm="Delete this <?php echo e($collection['singular']); ?>?" data-confirm-text="“<?php echo e($item->field($collection['title']) ?: 'Untitled'); ?>” will be removed from the site. This cannot be undone." data-confirm-button="Delete">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="sm danger" type="submit">Delete</button>
              </form>
            </span>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Mylaravel\Portfolie\resources\views/admin/items/index.blade.php ENDPATH**/ ?>