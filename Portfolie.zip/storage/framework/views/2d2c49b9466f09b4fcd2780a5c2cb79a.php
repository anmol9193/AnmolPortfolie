<?php
    $statIcons = ['clock', 'code', 'star', 'bolt'];
    $chipIcons = ['bolt', 'clock', 'ball', 'plane', 'star'];
?>
<!-- ABOUT (BENTO) -->
<section id="about">
  <div class="container">
    <?php echo $__env->make('site.sections._head', ['group' => 'about'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="bento">
      <div class="card b-intro reveal">
        <h3><?php echo e(rich(content('about.intro'))); ?></h3>
        <div>
          <?php $__currentLoopData = ['about.text_1', 'about.text_2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(content($key)): ?>
              <p><?php echo e(rich(content($key))); ?></p>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="b-sign"><img src="<?php echo e(media(content('site.photo'))); ?>" alt=""><div><b><?php echo e(content('site.name')); ?></b><span><?php echo e(content('about.sign_role')); ?></span></div></div>
      </div>
      <a href="<?php echo e($onHome ? '#experience' : url('experience')); ?>" class="card b-role reveal">
        <span class="arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17L17 7M7 7h10v10"/></svg></span>
        <small><?php echo e(content('about.role_label')); ?></small>
        <div><h4><?php echo e(content('about.role_company')); ?></h4><p><?php echo e(content('about.role_text')); ?></p></div>
      </a>
      <?php $__currentLoopData = \App\Support\Content::stats('about.stats'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => [$number, $suffix, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card b-stat reveal">
          <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><?php echo e(icon($statIcons[$i % count($statIcons)])); ?></svg></div>
          <div><b><?php echo e($number); ?><?php if($suffix): ?><sup><?php echo e($suffix); ?></sup><?php endif; ?></b><span><?php echo e($label); ?></span></div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="card b-loc reveal">
        <div class="pin"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div>
        <div><small><?php echo e(content('about.location_label')); ?></small><h4><?php echo e(content('about.location')); ?></h4><p><?php echo e(content('about.location_text')); ?></p></div>
      </div>
      <div class="card b-hob reveal">
        <small><?php echo e(content('about.hobbies_label')); ?></small>
        <div class="chips">
          <?php $__currentLoopData = \App\Support\Content::lines('about.hobbies'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="chip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><?php echo e(icon($chipIcons[$i % count($chipIcons)])); ?></svg><?php echo e($hobby); ?></span>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
</section>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/site/sections/about.blade.php ENDPATH**/ ?>