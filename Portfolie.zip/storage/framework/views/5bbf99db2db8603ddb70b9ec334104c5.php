
<style>
body{display:flex;flex-direction:column}
body > *{flex:none}
.hero{order:0}
.marquee{order:1}
<?php $__currentLoopData = $theme['order']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
#<?php echo e($id); ?>{order:<?php echo e(($i + 1) * 10); ?>}
<?php if($id === 'services'): ?>
.marquee.accent-strip{order:<?php echo e(($i + 1) * 10); ?>}
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
.cta{order:900}
#contact{order:910}
footer{order:990}
</style>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/partials/section-order.blade.php ENDPATH**/ ?>