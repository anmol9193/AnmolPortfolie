<!-- ACCENT STRIP -->
<div class="marquee accent-strip" aria-hidden="true"><div class="m-track rev" id="strip"></div></div>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/site/sections/strip.blade.php ENDPATH**/ ?>