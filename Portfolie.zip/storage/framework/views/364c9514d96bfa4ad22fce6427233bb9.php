<!-- EDUCATION -->
<section id="education" style="padding-top:40px">
  <div class="container">
    <?php echo $__env->make('site.sections._head', ['group' => 'education'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="edu-grid">
      <?php $__currentLoopData = items('education'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['card', 'edu', 'main' => $edu->field('main'), 'reveal']); ?>">
          <div class="yr"><span><?php echo e($edu->field('level')); ?></span><span><?php echo e($edu->field('status')); ?></span></div>
          <div class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><?php echo e(icon($edu->field('icon'), 'graduation')); ?></svg></div>
          <h3><?php echo e($edu->field('title')); ?></h3>
          <p><?php echo e($edu->field('description')); ?></p>
          <?php if($edu->field('board')): ?>
            <span class="board"><?php echo e($edu->field('board')); ?></span>
          <?php endif; ?>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/site/sections/education.blade.php ENDPATH**/ ?>