
<style>
html[data-theme]{--accent:<?php echo e($theme['accent']); ?>;--accent-2:<?php echo e($theme['accent2']); ?>;--accent-ink:<?php echo e($theme['ink']); ?>;--accent-soft:<?php echo e($theme['soft']); ?>;--radius:<?php echo e($theme['radius']); ?>}
<?php if($theme['bg']): ?>

<?php if($theme['mode'] === 'dark'): ?>
html[data-theme]{--bg:<?php echo e($theme['bg']); ?>;--bg-2:color-mix(in srgb,<?php echo e($theme['bg']); ?> 96%,#fff);--surface:color-mix(in srgb,<?php echo e($theme['bg']); ?> 93%,#fff);--surface-2:color-mix(in srgb,<?php echo e($theme['bg']); ?> 88%,#fff);--border:color-mix(in srgb,<?php echo e($theme['bg']); ?> 81%,#fff);--nav-bg:color-mix(in srgb,<?php echo e($theme['bg']); ?> 68%,transparent)}
<?php else: ?>
html[data-theme]{--bg:<?php echo e($theme['bg']); ?>;--bg-2:color-mix(in srgb,<?php echo e($theme['bg']); ?> 96%,#000);--surface:color-mix(in srgb,<?php echo e($theme['bg']); ?> 45%,#fff);--surface-2:color-mix(in srgb,<?php echo e($theme['bg']); ?> 92%,#000);--border:color-mix(in srgb,<?php echo e($theme['bg']); ?> 85%,#000);--nav-bg:color-mix(in srgb,<?php echo e($theme['bg']); ?> 55%,rgba(255,255,255,.55))}
<?php endif; ?>
<?php endif; ?>
<?php echo $__env->make('partials.theme-background', ['background' => $theme['background'], 'scope' => 'html body'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</style>
<?php /**PATH D:\Mylaravel\Portfolie\resources\views/partials/theme.blade.php ENDPATH**/ ?>